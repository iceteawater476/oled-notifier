package com.oledrelay.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class NotifyListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d("NotifyListener", "Service connected and listening")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        val packageName = sbn.packageName ?: return
        Log.d("NotifyListener", "Notification received from: $packageName")

        // Don't forward our own app's notifications.
        if (packageName == applicationContext.packageName) {
            Log.d("NotifyListener", "Ignoring our own notification")
            return
        }

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString() ?: ""
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""
        
        Log.d("NotifyListener", "Incoming: $packageName | Title: $title | Text: $text | Sub: $subText")

        val appLabel = try {
            val pm = applicationContext.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            packageName
        }

        val finalTitle = title.ifBlank { subText }.ifBlank { appLabel }
        val finalText = text.ifBlank { bigText }

        if (finalTitle.isBlank() && finalText.isBlank()) {
            Log.d("NotifyListener", "Content blank, skipping")
            return
        }

        val deviceIp = Prefs.deviceIp(applicationContext)
        if (deviceIp.isBlank()) return

        val onlyAppsString = Prefs.onlyApps(applicationContext)
        val ignoreAppsString = Prefs.ignoreApps(applicationContext)

        val onlyApps = onlyAppsString.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("e.g.") }
        val ignoreApps = ignoreAppsString.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("e.g.") }

        val haystack = (packageName + " " + appLabel).lowercase()
        if (onlyApps.isNotEmpty() && onlyApps.none { haystack.contains(it) }) {
            Log.d("NotifyListener", "FILTERED (not in OnlyApps): $appLabel ($packageName)")
            return
        }
        if (ignoreApps.any { haystack.contains(it) }) {
            Log.d("NotifyListener", "FILTERED (in IgnoreApps): $appLabel ($packageName)")
            return
        }

        Log.i("NotifyListener", "FORWARDING: $finalTitle from $appLabel")
        NotifySender.send(
            deviceIp = deviceIp,
            app = appLabel,
            title = finalTitle,
            message = finalText,
            durationMs = Prefs.durationMs(applicationContext)
        )
    }
}
