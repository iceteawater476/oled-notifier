package com.oledrelay.app

import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object NotifySender {
    private const val TAG = "NotifySender"

    /**
     * Fire-and-forget send to the ESP32 panel's /notify endpoint. Spins up
     * its own background thread so a slow or unreachable device never
     * blocks notification processing (NotificationListenerService callbacks
     * should return quickly).
     */
    fun send(deviceIp: String, app: String, title: String, message: String, file: String = "", durationMs: Int = 6000) {
        if (deviceIp.isBlank()) {
            Log.w(TAG, "No device IP configured, dropping notification")
            return
        }
        Thread {
            try {
                val query = listOf(
                    "app" to app,
                    "title" to title,
                    "message" to message,
                    "file" to file,
                    "duration" to durationMs.toString()
                ).joinToString("&") { (k, v) -> "$k=" + URLEncoder.encode(v, "UTF-8") }

                val cleanIp = deviceIp.removePrefix("http://").removePrefix("https://").trimEnd('/')
                val url = URL("http://$cleanIp/notify?$query")
                Log.d(TAG, "Hitting URL: $url")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val code = conn.responseCode
                conn.disconnect()
                Log.d(TAG, "Sent! Response code: $code")
            } catch (e: Exception) {
                Log.e(TAG, "ERROR sending notification: ${e.message}", e)
            }
        }.start()
    }
}
