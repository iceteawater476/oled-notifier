package com.oledrelay.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var deviceIpInput: EditText
    private lateinit var onlyAppsInput: EditText
    private lateinit var ignoreAppsInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        android.util.Log.i("OLED_DEBUG", "MainActivity onCreate")

        deviceIpInput = findViewById(R.id.deviceIpInput)
        onlyAppsInput = findViewById(R.id.onlyAppsInput)
        ignoreAppsInput = findViewById(R.id.ignoreAppsInput)
        durationInput = findViewById(R.id.durationInput)
        statusText = findViewById(R.id.statusText)

        val savedOnlyApps = Prefs.onlyApps(this)
        val savedIgnoreApps = Prefs.ignoreApps(this)
        
        deviceIpInput.setText(Prefs.deviceIp(this))
        if (savedOnlyApps.isNotEmpty()) onlyAppsInput.setText(savedOnlyApps)
        if (savedIgnoreApps.isNotEmpty()) ignoreAppsInput.setText(savedIgnoreApps)
        durationInput.setText(Prefs.durationMs(this).toString())

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val duration = durationInput.text.toString().toIntOrNull() ?: 6000
            Prefs.save(
                this,
                deviceIpInput.text.toString(),
                onlyAppsInput.text.toString(),
                ignoreAppsInput.text.toString(),
                duration
            )
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.grantAccessButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.testButton).setOnClickListener {
            if (!isNotificationAccessGranted()) {
                Toast.makeText(this, "ERROR: Notification Access NOT granted!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val deviceIp = deviceIpInput.text.toString()
            if (deviceIp.isBlank()) {
                Toast.makeText(this, "Enter a device IP first", Toast.LENGTH_SHORT).show()
            } else {
                NotifySender.send(
                    deviceIp = deviceIp,
                    app = "OLED Notify Relay",
                    title = "Test notification",
                    message = "If you see this on the OLED, it's working!"
                )
                Toast.makeText(this, "Test sent", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        statusText.text = if (isNotificationAccessGranted()) {
            "Notification access: granted\n(If it still doesn't work, try turning it off and on in settings)"
        } else {
            "Notification access: NOT granted -- tap the button below and enable it for this app"
        }
    }

    private fun rebindService() {
        val cn = android.content.ComponentName(this, NotifyListenerService::class.java)
        NotificationListenerService.requestRebind(cn)
        Toast.makeText(this, "Requested service rebind", Toast.LENGTH_SHORT).show()
    }

    private fun isNotificationAccessGranted(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val components = flat.split(":")
        for (component in components) {
            val cn = android.content.ComponentName.unflattenFromString(component)
            if (cn != null && cn.packageName == packageName) {
                return true
            }
        }
        return false
    }
}
